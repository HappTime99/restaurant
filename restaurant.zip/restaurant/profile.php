<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header('Location: login.php');
    }else{

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
</head>
<body>
            <?php 
                include('include/linkcss.php');
                include('include/linkjs.php');
                include('include/connect.php');
                include('include/sidebar_menu.php');
            
                
            ?>
       
        <h1 class="text-center mt-5">ข้อมูลโปรไฟล์</h1>
        
        <hr>
        <form action="" method="post">
            <input type="hidden" name="id" id="id">
                    
            <div class="container col-md-7">
                <div class="form-group " >
                    <label for="" class="form-control text-center">ชื่อ : &emsp;<?php echo $result['fname'];?></label><br>
                </div>

                <div class="form-group">
                    <label for="" class="form-control text-center">นามสกุล : &emsp;<?php echo $result['lname'];?></label><br>
                </div>

                <div class="form-group">
                    <label for="" class="form-control text-center">เบอร์โทร: &emsp;<?php echo $result['tel'];?></label><br>
                </div>

                <div class="form-group">
                    <label for="" class="form-control text-center">ที่อยู่ : &emsp;<?php echo $result['paddress'];?></label><br>
                </div>

                <div class="form-group">
                    <label for="" class="form-control text-center">ชื่อผู้ใช้งาน : &emsp;<?php echo $result['pusername'];?></label><br>
                </div>
            </div>
            <div class="text-center">
                <a href="edit_profile?id=<?php echo $row['id'];?>" class="btn btn-success">แก้ไข</a>
            </div>
           
        </form>
  
        
</body>
</html>
<?php } ?> 


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!--========== BOX ICONS ==========-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/boxicons@latest/css/boxicons.min.css">

    <!--========== CSS ==========-->
    <link rel="stylesheet" href="assets/css/styles.css">

    <title>Responsive sidebar submenus</title>
</head>

<body>
   
    <!--========== HEADER ==========-->
    <header class="header">
        <div class="header__container">
               <img src="assets/img/girl.jpg" alt="" class="header__img" >
               
               
           
            
        

            <img src="" class="header__logo">
          


            <div class="header__toggle">
                <i class='bx bx-menu' id="header-toggle"></i>
            </div>
        </div>
    </header>

    <!--========== NAV ==========-->
    <div class="nav" id="navbar">
        <nav class="nav__container">
            <div>
                

                <div class="nav__list">
                    <div class="nav__items">
                        

                        <a href="index.php" class="nav__link active">
                            <i class='bx bx-home nav__icon'></i>
                            <span class="nav__name">หน้าหลัก</span>
                        </a>

                        <a href="user.php" class="nav__link active">
                            <i class='bx bx-plus nav__icon'></i>
                            <span class="nav__name">ข้อมูลผู้ใช้งาน</span>
                        </a>

                        <div class="nav__dropdown">
                            <a href="" class="nav__link">
                                <i class='bx bx-food-menu nav__icon'></i>
                                <span class="nav__name">ข้อมูลอาหาร</span>
                                <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                            </a>

                            <div class="nav__dropdown-collapse">
                                <div class="nav__dropdown-content">
                                    <a href="food.php" class="nav__dropdown-item">รายการอาหาร</a>
                                    <a href="order.php" class="nav__dropdown-item">สั่งอาหาร</a>
                                    
                                </div>
                            </div>
                        </div>

                        <a href="customer.php" class="nav__link">
                            <i class='bx bx-message-rounded nav__icon'></i>
                            <span class="nav__name">ข้อมูลลูกค้า</span>
                        </a>
                    </div>

                    <div class="nav__items">

                        <div class="nav__dropdown">
                            <a href="" class="nav__link">
                                <i class='bx bx-table'></i>
                                <span class="nav__name">ข้อมูลโต๊ะอาหาร</span>
                                <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                            </a>

                            <div class="nav__dropdown-collapse">
                                <div class="nav__dropdown-content">
                                
                                    <a href="Reserve.php" class="nav__dropdown-item">จองโต๊ะอาหาร</a>
                                    <a href="service.php" class="nav__dropdown-item">รับบริการ</a>
                                    
                                </div>
                            </div>
                        </div>

                        <a href="pay.php" class="nav__link">
                            <i class='bx bx-credit-card '></i>
                            <span class="nav__name">ข้อมูลชำระเงิน</span>
                        </a>

                        <div class="nav__dropdown">
                            <a href="" class="nav__link">
                                <i class='bx bx-bookmark'></i>
                                <span class="nav__name">รายงานผล</span>
                                <i class='bx bx-chevron-down nav__icon nav__dropdown-icon'></i>
                            </a>

                            <div class="nav__dropdown-collapse">
                                <div class="nav__dropdown-content">
                                
                                    <a href="report_orderfood.php" class="nav__dropdown-item">สั่งอาหาร</a>
                                    <a href="report_customer.php" class="nav__dropdown-item">ลูกค้า</a>
                                    <a href="report_user.php" class="nav__dropdown-item">ผู้ใช้งาน</a>
                                    <a href="report_reserve.php" class="nav__dropdown-item">จองโต๊ะอาหาร</a>
                                    <a href="report_pay.php" class="nav__dropdown-item">ชำระเงิน</a>   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <a href="logout.php" class="nav__link nav__logout">
                <i class='bx bx-log-out nav__icon'></i>
                <span class="nav__name">Log Out</span>
            </a>
        </nav>
    </div>

    <!--========== CONTENTS ==========-->
    
    <main>
            <section>
                
            </section>
        </main>

    <!--========== MAIN JS ==========-->
    <script src="assets/js/main.js"></script>
</body>

</html>
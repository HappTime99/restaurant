<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
         include('include/linkcss.php');
         include('include/linkjs.php');
         include('include/connect.php');
         include('include/sidebar_menu.php');
     
    ?>
    <h1 class="text-center mt-5">รายงานผลชำระเงิน</h1>
    <hr>
    <form action="" method="post">
        <div class="container-fluid">
            
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>รายการอาหาร </th>
                        <th>จำนวน</th>
                        <th>ราคา</th>
                        <th>ผลรวม</th>

                    </tr>
                </thead>
                <tbody>
                    <?php
                        $query = mysqli_query($conn,"SELECT * FROM pay");
                        while($row = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td><?php echo $row['pay_id'];?></td>
                        <td><?php echo $row['pay_food'];?></td>
                        <td><?php echo $row['pay_number'];?></td>
                        <td><?php echo $row['pay_price'];?></td>
                        <td><?php echo $row['pay_sum'];?></td>
                     
                    </tr>

                </tbody>
                <?php } ?>
            </table>
        </div>
    </form>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php   include('include/footer.php');?>
</html>
<?php } ?>
<?php 

        session_start();

        if (!isset($_SESSION['userid'])) {
            header("Location: login.php");
        }else{
        
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    
</head>

<body>
    
    <?php 
        include('include/linkcss.php');
        include('include/linkjs.php');
        include('include/connect.php');
        include('include/sidebar_menu.php');

        
        //query
        $querydata = mysqli_query($conn,"SELECT * FROM user");


        //insert
        if(isset($_POST['insert'])){
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $ptel = $_POST['tel'];
            $paddress = $_POST['address'];
            $puser = $_POST['pusername'];
            $ppass = md5($_POST['ppassword']);
            

            $insertdata = mysqli_query($conn,"INSERT INTO user(fname,lname,tel,paddress,pusername,ppassword) VALUES('$fname','$lname','$ptel','$paddress','$puser','$ppass')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href='user.php'</script>";
              } 
        }

        //update
        if(isset($_POST['update'])){
            $userid = $_POST['id'];
            $fname = $_POST['fname'];
            $lname = $_POST['lname'];
            $ptel = $_POST['tel'];
            $paddress = $_POST['paddress'];
            $puser = $_POST['pusername'];
            $ppass = md5($_POST['ppassword']);
            $status = $_POST['status'];

            $updatedata = mysqli_query($conn,"UPDATE user SET
            fname = '$fname',
            lname = '$lname',
            tel = '$ptel',
            paddress = '$paddress',
            pusername = '$puser',
            ppassword = '$ppass',
            status = '$status'
            WHERE id = '$userid'
            ");
          
            if($updatedata) {
                echo "<script>alert('Update Successfully!');</script>";
                echo "<script>window.location.href='user.php'</script>";
              } 
        }
        
        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM user WHERE id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href='user.php'</script>";
              } 
        }
          
    ?>

    <form action="" method="POST">
                
        <!-- Modal insert-->
        <div class="modal fade" id="adddata"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลชื่อผู้ใช้</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               
                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">ชื่อ</span>
                        </div>
                        <input type="text" class="form-control"  name="fname" placeholder="กรุณากรอกชื่อพนักงาน"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">นามสกุล</span>
                        </div>
                        <input type="text" class="form-control"  name="lname"   placeholder="กรุณากรอกนามสกุลพนักงาน"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">เบอร์โทร</span>
                        </div>
                        <input type="text" class="form-control"  name="tel"  placeholder="กรุณากรอกเบอร์โทร"  require>
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">ที่อยู่</span>
                        </div>
                        <textarea type="text" class="form-control" name="paddress" placeholder="กรุณากรอกที่อยู่"require> 
                        </textarea >
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                style="color: #d80041;min-width: 130px">ชื่อผู้ใช้งาน</span>
                        </div>
                            <input type="text" class="form-control" name="pusername"  placeholder="กรุณากรอกชื่อผู้ใช้งาน"  require>
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                style="color: #d80041;min-width: 130px">รหัสผ่านผู้ใช้งาน</span>
                        </div>
                            <input type="password" class="form-control" name="ppassword"  placeholder="กรุณากรอกรหัสผู้ใช้งาน"  require>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
        </div>

    </form>

        
    <form action="" method="post">
                
                <!-- Modal update-->
                <div class="modal fade" id="editmodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลผู้ใช้งาน</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="id" id="id">
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ชื่อ</span>
                                </div>
                                <input type="text" class="form-control" id="fname"  name="fname" placeholder="กรุณากรอกชื่อ" require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">นามสกุล</span>
                                </div>
                                <input type="text" class="form-control" id="lname"  name="lname"  placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">เบอร์โทร</span>
                                </div>
                                <input type="text" class="form-control" id="tel"  name="tel"  placeholder="กรุณากรอกเบอร์โทร"  require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ที่อยู่</span>
                                </div>
                                <textarea type="text" placeholder="กรุณากรอกรายละเอียด" id="paddress"  name="paddress" class="form-control"    require> 
                                </textarea >
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ชื่อผู้ใช้งาน</span>
                                </div>
                                <input type="text" class="form-control" id="pusername"  name="pusername"  placeholder="กรุณากรอกชื่อผู้ใช้งาน"  require>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">รหัสผ่านผู้ใช้งาน</span>
                                </div>
                                <input type="password" class="form-control" id="ppassword"  name="ppassword"  placeholder="กรุณากรอกรหัสผู้ใช้งาน"  require>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="status"  class="form-control">
                                    <option value="0"  >ลาออก
                                    </option>
                                    <option value="1"  >ทำงาน
                                    </option>
                                </select>
                            </div>
                        </div>

                        

                        

                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
                  
    </form>
    
        
    
    <h1 class="text-center mt-3">ข้อมูลผู้ใช้งาน</h1>
    <hr>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adddata">
            เพิ่ม <i class="fas fa-plus"></i>
        </button>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>ชื่อ</th>
                <th>นามสกุล</th>
                <th>เบอร์โทร</th>
                <th>ที่อยู่</th>
                <th>ชื่อผู้ใช้งาน</th>
                <th>รหัสผู้ใช้งาน</th>
                <th>สถานะ</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($row = mysqli_fetch_array($querydata)){
            ?>
            <tr>
                <td><?php echo $row['id'];?></td>
                <td><?php echo $row['fname'];?></td>
                <td><?php echo $row['lname'];?></td>
                <td><?php echo $row['tel'];?></td>
                <td><?php echo $row['paddress'];?></td>
                <td><?php echo $row['pusername'];?></td>
                <td><?php echo $row['ppassword'];?></td>
                <?php
                      $st = '';
                      if($row['status'] == 0 ){
                          $st = "ลาออก";
                      }else{
                          $st = "ทำงาน";
                      }
                  echo '<td>' . $st . '</td>' ;
                  ?>
            
                <td><button type="button" class="btn btn-danger editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                    <a href="user.php?del=<?php echo $row['id'];?>" class="btn btn-dark">ลบ <i class="fas fa-trash-alt"></i></a>
            </td>
                
            </tr>
            <?php } ?>
        </tbody>

    </table>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
    <script>
        $(document).ready(function (){
            $('.editbtn').on('click',function(){

                $('#editmodal').modal('show');
                    $st = $(this).closest('tr');
                    var data = $st.children("td").map(function(){
                        return $(this).text();
                    }).get();
                    console.log(data);

                    $('#id').val(data[0]);
                    $('#fname').val(data[1]);
                    $('#lname').val(data[2]);
                    $('#tel').val(data[3]);
                    $('#paddress').val(data[4]);
                    $('#pusername').val(data[5]);
                    $('#ppassword').val(data[6]);
                    $('#status').val(data[7]);
                    
            });    
        });
    </script>
    
</body>
<?php   include('include/footer.php');?>

</html>
<?php }  ?>
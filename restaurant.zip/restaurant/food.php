<?php
   session_start();

   if (!isset($_SESSION['userid'])) {
       header("Location: login.php");
   }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <?php 
        include('include/connect.php');
        include('include/linkcss.php');
        include('include/linkjs.php');
        include('include/sidebar_menu.php');

        
        //query
        $querydata = mysqli_query($conn,"SELECT * FROM food ");


        //insert
        if(isset($_POST['insert'])){
            
            $image_file = $_FILES['food_pic_path']['name']; //ไฟล์ + ชื่อ
            $temp = $_FILES['food_pic_path']['tmp_name']; //ที่อยู่ไฟล์ 
            $size = $_FILES['food_pic_path']['size']; // ขนาดของไฟล์

            $path = "upload/".$image_file;

            if(!file_exists($path)){
                if($size < 10000000){
                    move_uploaded_file($temp,$path);
                }
            }

            $fmenu = $_POST['food_menu'];
            $fprice = $_POST['food_price'];
            $fcate = $_POST['food_category'];


            
            $insertdata = mysqli_query($conn,"INSERT INTO food(food_pic_path,food_menu,food_price,food_category) 
            VALUES('$image_file','$fmenu','$fprice','$fcate')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href='food.php'</script>";
              } 
        }

        //update
        if(isset($_POST['update'])){
            $userid = $_POST['food_id'];
            
            $fmenu = $_POST['food_menu'];
            $fprice = $_POST['food_price'];
            $fcate = $_POST['food_category'];
            $fstatus = $_POST['food_status'];




            $updatedata = mysqli_query($conn,"UPDATE food SET
            food_menu = '$fmenu',
            food_price = '$fprice',
            food_category = '$fcate',
            food_status = '$fstatus'
            WHERE food_id = '$userid'
            ");

            
            if($updatedata ) {
                echo "<script>alert('update Successfully!');</script>";
                echo "<script>window.location.href='food.php'</script>";
              } 
        }
        
        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM food WHERE food_id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href='food.php'</script>";
              } 
        }
          
    ?>

    <form action="" method="POST" enctype="multipart/form-data">
                
        <!-- Modal insert-->
        <div class="modal fade" id="adddata"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลรายอาการ</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">รูปอาหาร</span>
                        </div>
                        <input type="file" class="custom-file-input form-control"  name="food_pic_path"  require>
                    </div>
                </div>


                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                        </div>
                        <input type="text" class="form-control"  name="food_menu" placeholder="กรุณากรอกรายการอาหาร"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">ราคา</span>
                        </div>
                        <input type="text" class="form-control"  name="food_price" placeholder="กรุณากรอกราคา"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">ประเภทอาหาร</span>
                        </div>
                        <input type="text" class="form-control"  name="food_category"   placeholder="กรุณากรอกประเภทอาหาร"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="food_status"   class="form-control">
                                    <option value="0"  >หมดแล้ว
                                    </option>
                                    <option value="1"  >มีอยู่
                                    </option>
                                </select>
                            </div>
                </div>

                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
        </div>

    </form>

    

    <form action="" method="post" enctype="multipart/form-data"> 
                
                <!-- Modal update-->
                <div class="modal fade" id="editmodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลรายการอาหาร</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                    <input type="hidden" name="food_id" id="food_id" >
                    
    
                       
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                                </div>
                                <input type="text" class="form-control" id="food_menu"  name="food_menu"  placeholder="กรุณากรอกชื่อ" require>
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">ราคา</span>
                                </div>
                                <input type="text" class="form-control" id="food_price"  name="food_price" placeholder="กรุณากรอกรายการอาหาร"   require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ประเภทอาหาร</span>
                                </div>
                                <input type="text" class="form-control" id="food_category"  name="food_category"   placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>
                        
                     

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="food_status"    class="form-control">
                                    <option value="0"  >หมดแล้ว
                                    </option>
                                    <option value="1"  >มีอยู่
                                    </option>
                                </select>
                            </div>
                        </div>
                        

                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
                  
    </form>
    
        
    
    <h1 class="text-center mt-3">ข้อมูลรายการอาหาร</h1>
    <hr>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adddata">
            เพิ่ม <i class="fas fa-plus"></i>
        </button>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>รูปอาหาร</th>
                <th>รายการอาหาร</th>
                <th>ราคา</th>
                <th>ประเภทอาหาร</th>
                <th>สถานะ</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($row = mysqli_fetch_array($querydata)){
            ?>
            <tr>
                <td><?php echo $row['food_id'];?></td>
                <td><img width="120px" height="80px" src="upload/<?php echo $row['food_pic_path'];?>"></td>
                <td><?php echo $row['food_menu'];?></td>
                <td><?php echo $row['food_price'];?></td>

                <td ><?php echo $row['food_category'];?></td>
                
                
                <?php
                      $st = '';
                      if($row['food_status'] == 1 ){
                          $st = "มีอยู่";
                      }else{
                          $st = "หมดแล้ว";
                      }
                  echo '<td>' . $st . '</td>' ;
                  ?>
            
                <td><button type="button" class="btn btn-danger editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                    <a href="food.php?del=<?php echo $row['food_id'];?>" class="btn btn-dark">ลบ <i class="fas fa-trash-alt"></i></a>
            </td>
                
            </tr>
            <?php } ?>
        </tbody>

    </table>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
    <script>
        $(document).ready(function (){
            $('.editbtn').on('click',function(){

                $('#editmodal').modal('show');
                    $st = $(this).closest('tr');
                    var data = $st.children("td").map(function(){
                        return $(this).text();
                    }).get();
                    console.log(data);

                    $('#food_id').val(data[0]);
                   
                    $('#food_menu').val(data[2]);
                    $('#food_price').val(data[3]);
                    $('#food_category').val(data[4]);
                    $('#food_status').val(data[5]);
                    
                    
                    

            });    
        });
    </script>
    
    
</body>
<?php   include('include/footer.php');?>
        

</html>

<?php } ?>
<?php
   session_start();

   if (!isset($_SESSION['userid'])){
       header("Location: login.php");
   }else{
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php 
        
        include('include/connect.php');
        include('include/linkcss.php');
        include('include/linkjs.php');
        include('include/sidebar_menu.php');


        //insert
        if(isset($_POST['insert'])){
            $order_food = $_POST['order_food'];
            $order_table = $_POST['order_table'];
            $order_category = $_POST['order_category'];
            $order_number = $_POST['order_number'];
            $order_status = $_POST['order_status'];
   
            $insertdata = mysqli_query($conn,"INSERT INTO order_food(order_food,order_table,order_category,order_number,order_status) 
            VALUES('$order_food','$order_table','$order_category','$order_number','$order_status')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href = 'order.php'</script>";
              } 
        }

        //update
        if(isset($_POST['update'])){
            $userid = $_POST['order_id'];
            $order_food = $_POST['order_food'];
            $order_table = $_POST['order_table'];
            $order_category = $_POST['order_category'];
            $order_number = $_POST['order_number'];
            $order_status = $_POST['order_status'];


            $updatedata = mysqli_query($conn,"UPDATE order_food SET
            order_food = '$order_food',
            order_table = '$order_table',
            order_category = '$order_category',
            order_number = '$order_number',
            order_status = '$order_status'
            WHERE order_id = '$userid'
            ");

            if($updatedata ) {
                echo "<script>alert('update Successfully!');</script>";
                echo "<script>window.location.href = 'order.php'</script>";
              } 
        }
        
        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM order WHERE order_id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href = 'order.php'</script>";
              } 
        }
          
    ?>

    <form action="" method="POST" enctype="multipart/form-data">

        <!-- Modal insert-->
        <div class="modal fade" id="adddata" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลสั่งอาหาร</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">เลขที่โต๊ะ</span>
                                </div>
                                <select name="order_table"  class="form-control"><?php for($num=1;$num<=30;$num++){echo "<option>$num</option>";}?></select>

                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                                </div>
                                <input type="text" class="form-control" name="order_food" placeholder="กรุณากรอกรายการอาหาร" require>
                            </div>
                        </div>

                       

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">ประเภทอาหาร</span>
                                </div>
                                <select name="order_category"  class="form-control">
                                    <option value="0">กลับบ้าน</option>
                                    <option value="1">ร้านอาหาร</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control" name="order_number" placeholder="กรุณากรอกจำนวน"
                                    require>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="order_status" class="form-control">
                                    <option value="0">ยกเลิกสั่งอาหาร
                                    </option>
                                    <option value="1">สั่งอาหาร
                                    </option>
                                </select>
                            </div>
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>

    </form>



    <form action="" method="post" enctype="multipart/form-data">

        <!-- Modal update-->
        <div class="modal fade" id="editmodal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลสั่งอาหาร</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <input type="hidden" name="order_id" id="order_id">

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">เลขที่โต๊ะ</span>
                                </div>
                                <select name="order_table" id="order_table"  class="form-control"><?php for($num=1;$num<=30;$num++){echo "<option>$num</option>";}?></select>

                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                                </div>
                                <input type="text" class="form-control" id="order_food" name="order_food" placeholder="กรุณากรอกรายการอาหาร" require>

                            </div>
                        </div>

                       

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">ประเภทอาหาร</span>
                                </div>
                                <select name="order_category"  class="form-control">
                                    <option value="0"  >กลับบ้าน</option>
                                    <option value="1"  >ร้านอาหาร</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control" name="order_number" id="order_number" placeholder="กรุณากรอกจำนวน"
                                    require>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="order_status" class="form-control">
                                    <option value="0">ยกเลิกสั่งอาหาร
                                    </option>
                                    <option value="1">สั่งอาหาร
                                    </option>
                                </select>
                            </div>
                        </div>


                    </div>

                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>

    </form>



    <h1 class="text-center mt-3">ข้อมูลสั่งอาหาร</h1>
    <hr>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adddata">
        เพิ่ม <i class="fas fa-plus"></i>
    </button>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>เลขที่โต๊ะ</th>
                <th>รายการอาหาร</th>
                <th>วันที่สั่ง</th>
                <th>ประเภท</th>
                <th>จำนวน</th>
                <th>สถานะ</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
            
                //query
                $querydata = mysqli_query($conn,"SELECT * FROM order_food");
                while($row = mysqli_fetch_array($querydata)){
            ?>
            <tr>
                <td><?php echo $row['order_id'];?></td>
                <td><?php echo $row['order_table'];?></td>
                <td><?php echo $row['order_food'];?></td>
                <td><?php echo $row['mdate'];?></td>
                
                
                    <?php
                      $or_cat = '';
                      if($row['order_category'] == 1 ){
                          $or_cat = "ร้านอาหาร";
                      }else{
                          $or_cat = "กลับบ้าน";
                      }
                    echo "<td>". $or_cat."</td>" ;
                    ?>
                
                <td><?php echo $row['order_number'];?></td>

                <?php
                      $or_tus = '';
                      if($row['order_status'] == 1 ){
                          $or_tus = "สั่งอาหาร";
                      }else{
                          $or_tus = "ยกเลิกสั่งอาหาร";
                      }
                  echo '<td>' . $or_tus . '</td>' ;
                  ?>

                <td><button type="button" class="btn btn-danger editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                    <a href="order.php?del=<?php echo $row['order_id'];?>" class="btn btn-dark">ลบ <i class="fas fa-trash-alt"></i></a>
                </td>

            </tr>
            <?php } ?>
        </tbody>

    </table>

    <script>
        $(document).ready(function () {
            $('.table').DataTable();
        });
    </script>
    <script>
        $(document).ready(function () {
            $('.editbtn').on('click', function () {

                $('#editmodal').modal('show');
                $st = $(this).closest('tr');
                var data = $st.children("td").map(function () {
                    return $(this).text();
                }).get();
                console.log(data);

                $('#order_id').val(data[0]);
                $('#order_table').val(data[1]);
                $('#order_food').val(data[2]);
                $('#order_category').val(data[4]);
                $('#order_number').val(data[5]);
                $('#order_status').val(data[6]);
            });
        });
    </script>


</body>
<?php   include('include/footer.php');?>


</html>

<?php } ?> 
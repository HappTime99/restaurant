<?php
  session_start();
  if(!isset($_SESSION['userid'])){
      header('Location: login.php');
  }else{
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <?php
      include('include/linkcss.php');
      include('include/linkjs.php');
      include('include/connect.php');
      include('include/sidebar_menu.php');

        if(isset($_POST['insert'])){
            $order_food = $_POST['order_food'];
            $order_table = $_POST['order_table'];
            $order_category = $_POST['order_category'];
            $order_number = $_POST['order_number'];
            

            $insertdata = mysqli_query($conn,"INSERT INTO order_food(order_food,order_table,order_category,order_number) 
            VALUES('$order_food','$order_table','$order_category','$order_number')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href = 'order.php'</script>";
            } 
        }

            $result= mysqli_query($conn,"SELECT * FROM food ORDER BY food_id ASC");
   
  ?>
  <h1 class="text-center">เมนูสั่งอาหาร</h1>
  <hr>
    <div class="row">

        <?php foreach ($result as $row){  ?>
        <div class="card ml-5 mt-5" style="width: 15rem;">
            <img  class="card-img-top" src="upload/<?php echo $row['food_pic_path'];?> " style="width:300px; height:170px; " alt="">
            <div class="card-body">
                <h5 class="card-title">
                    <?php echo $row['food_menu'];?>
                    <?php echo $row['food_price'];?>
                </h5>
                
            </div>
            <button type="button" class="btn btn-primary " data-bs-toggle="modal" data-bs-target="#adddata">สั่งอาหาร
                    <i class="fas fa-plus"></i></button>
        </div>
        <?php } ?>

    </div>

    <form action="" method="POST">

        <!-- Modal insert-->
        <div class="modal fade" id="adddata" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลชื่อผู้ใช้</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">เลขที่โต๊ะ</span>
                                </div>
                                <select name="order_table" class="form-control">
                                    <?php for($num=1;$num<=30;$num++){echo "<option>$num</option>";}?>
                                </select>

                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                                </div>
                                <input type="text" class="form-control" name="order_food"
                                    placeholder="กรุณากรอกรายการอาหาร" require>
                            </div>
                        </div>



                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">ประเภทอาหาร</span>
                                </div>
                                <select name="order_category" class="form-control">
                                    <option value="0">กลับบ้าน</option>
                                    <option value="1">ร้านอาหาร</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text" style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control" name="order_number" placeholder="กรุณากรอกจำนวน"
                                    require>

                            </div>
                        </div>

                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
            </div>
        </div>

    </form>


</body>
<?php   include('include/footer.php');?>
</html>

<?php } ?>
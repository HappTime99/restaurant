<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header('Location: login.php');
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('include/connect.php');
        include('include/sidebar_menu.php');

        //insert
            if(isset($_POST['insert'])){
                $payfood =  $_POST['pay_food'];
                $paynumber= $_POST['pay_number'];
                $payprice = $_POST['pay_price'];
                $paysum = $_POST['pay_sum'];

            $insertdata = mysqli_query($conn,"INSERT INTO pay(pay_food,pay_number,pay_price,pay_sum) 
            VALUES('$payfood','$paynumber','$payprice','$paysum')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href='pay.php'</script>";
            } 
        }

        //update
        if(isset($_POST['update'])){
            $userid= $_POST['pay_id'];
            $payfood = $_POST['pay_food'];
            $paynumber = $_POST['pay_number'];
            $payprice = $_POST['pay_price'];
            $paysum = $_POST['pay_sum'];

            $updatedata = mysqli_query($conn,"UPDATE pay SET
            pay_food    = '$payfood',
            pay_number  = '$paynumber',
            pay_price   = '$payprice',
            pay_sum     = '$paysum'
            WHERE pay_id = '$userid'
            ");
            if($updatedata ) {
                echo "<script>alert('Update Successfully!');</script>";
                echo "<script>window.location.href='pay.php'</script>";
            } 
        }

        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM pay WHERE pay_id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href='pay.php'</script>";
            } 
        }

    ?>

<form action="" method="post" enctype="multipart/form-data"> 
                
                <!-- Modal update-->
                <div class="modal fade" id="editmodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลชำระเงิน</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                    <input type="hidden" name="pay_id" id="pay_id" >
                    

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                                </div>
                                <input type="text" class="form-control" id="pay_food"  name="pay_food" placeholder="กรุณากรอกรายการอาหาร"   require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control" id="pay_number"  name="pay_number"   placeholder="กรุณากรอกจำนวน"  require>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ราคา</span>
                                </div>
                                <input type="text" class="form-control" id="pay_price"  name="pay_price"   placeholder="กรุณากรอกราคา"  require>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ผลรวม</span>
                                </div>
                                <input type="text" class="form-control" id="pay_sum"  name="pay_sum"   placeholder="กรุณากรอกผลรวม"  require>
                                
                            </div>
                        </div>
                        

                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
                  
    </form>

    <form action="<?= $_SERVER['PHP_SELF']?>" method="POST" enctype="multipart/form-data">
                
        <!-- Modal insert-->
        <div class="modal fade" id="adddata"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลชำระเงิน</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?=$_SERVER['PHP_SELF']?>" method="post">
                            <div class="form-group">
                                <div class="input-group mb-4 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">รายการอาหาร</span>
                                    </div>
                                        <input type="text" class="form-control"  name="pay_food" placeholder="กรุณากรอกรายการอาหาร"  require>  
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group mb-4 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จำนวน</span>
                                    </div>
                                        <input type="number" class="form-control"  name="pay_number" placeholder="กรุณากรอกจำนวน"  require>  
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group mb-4 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ราคา</span>
                                    </div>
                                        <input type="number" class="form-control"  name="pay_price" placeholder="กรุณากรอกราคา"  require>  
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group mb-4 ">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ผลรวม</span>
                                    </div>
                                        <input type="number" class="form-control" name="pay_sum" placeholder="กรุณากรอกผลรวม"  require  >    
                                </div>
                                 
                                
                            </div>
                        </form>
                        
                        
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
        
    </form>
   
        
    
    <h1 class="text-center mt-3">ข้อมูลชำระเงิน</h1>
    <hr>
     <!-- Button trigger modal -->
    <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#adddata"> เพิ่ม <i class="fas fa-plus"></i></button>
    <table class="table">
        <thead>
            <tr>
                <th class="text-center">#</th>
                <th class="text-center">รายการอาหาร</th>
                <th class="text-center">จำนวน</th>
                <th class="text-center">ราคา</th>
                <th class="text-center">ผลรวม</th>
                <th class="text-center">จัดการ</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
                $query = mysqli_query($conn,"SELECT * FROM pay");
                while($row = mysqli_fetch_array($query)){
                
            ?>
            <tr>
                <td class="text-center"><?php echo $row["pay_id"];?></td>
                <td class="text-center"><?php echo $row["pay_food"];?></td>
                <td class="text-center"><?php echo $row["pay_number"];?></td>
                <td class="text-center"><?php echo $row["pay_price"];?></td>
                <td class="text-center"><?php echo $row['pay_sum'];?></td>
                <td class="text-center"><button type="button" class="btn btn-info editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                    <a href="pay.php?del=<?php echo $row['pay_id'];?>" class="btn btn-dark">ลบ <i class="fas fa-trash-alt"></i></a>
                </td>
            </tr>
            <?php } ?>
        </tbody>
  

    </table>
    
    <script>
        $(document).ready(function (){
            $('.editbtn').on('click',function(){

                $('#editmodal').modal('show');
                    $st = $(this).closest('tr');
                    var data = $st.children("td").map(function(){
                        return $(this).text();
                    }).get();
                    console.log(data);

                    $('#pay_id').val(data[0]);
                    $('#pay_food').val(data[1]);
                    $('#pay_number').val(data[2]);
                    $('#pay_price').val(data[3]);
                    $('#pay_sum').val(data[4]);

            });    
        });
    </script>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php   include('include/footer.php');?>

</html>

<?php } ?>
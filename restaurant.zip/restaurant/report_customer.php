<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php   
         include('include/linkcss.php');
         include('include/linkjs.php');
         include('include/connect.php');
         include('include/sidebar_menu.php');
     
    ?>
    <h1 class="text-center mt-5">รายงานผลลูกค้า</h1>
    <hr>
    <form action="" method="post">
        <div class="container-fluid">
            
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ชื่อ</th>
                        <th>นามสกุล</th>
                        <th>ที่อยู่</th>
                        <th>เบอร์โทร</th>
                        <th>สถานะ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $query = mysqli_query($conn,"SELECT * FROM customer");
                        while($row = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td><?php echo $row['customer_id'];?></td>
                        <td><?php echo $row['customer_name'];?></td>
                        <td><?php echo $row['customer_surname'];?></td>
                        <td><?php echo $row['customer_address'];?></td>
                        <td><?php echo $row['customer_tel'];?></td>

                        <?php
                            $st = '';
                            if($row['customer_status'] == 1 ){
                                $st = "ใช้งาน";
                            }else{
                                $st = "ไม่ใช้งาน";
                            }
                            echo '<td>' . $st . '</td>' ;
                        ?>
                    </tr>

                </tbody>
                <?php } ?>
            </table>
        </div>
    </form>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php   include('include/footer.php');?>
</html>
<?php } ?>
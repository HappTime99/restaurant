<?php
   session_start();

   if (!isset($_SESSION['userid'])) {
       header("Location: login.php");
   }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('include/connect.php');
        include('include/sidebar_menu.php');

        //insert
        if(isset($_POST['insert'])){
            
            $table_id = $_POST['table_id'];
            $ser_number = $_POST['service_number'];
            $ser_numberh = $_POST['service_numberh'];
            $ser_status = $_POST['service_status'];
            
            

            $insertdata = mysqli_query($conn,"INSERT INTO services(table_id,service_number,service_numberh,service_status)
            VALUES('$table_id','$ser_number','$ser_numberh','$ser_status')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href='service.php'</script>";
            } 
        }

        //update
        if(isset($_POST['update'])){
            $userid = $_POST['service_id'];
            $table_id = $_POST['table_id'];
            $service_number = $_POST['service_number'];
            $service_numberh = $_POST['service_numberh'];
            $service_status = $_POST['service_status'];

            $updatedata = mysqli_query($conn,"UPDATE services SET
            table_id = '$table_id',
            service_number = '$service_number',
            service_numberh = '$service_numberh',
            service_status = '$service_status'
            WHERE service_id = '$userid'
            ");
            if($updatedata ) {
                echo "<script>alert('Update Successfully!');</script>";
                echo "<script>window.location.href='service.php'</script>";
              } 
        }

        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM services WHERE service_id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href='service.php'</script>";
              } 
        }

    ?>

<form action="" method="post" enctype="multipart/form-data"> 
                
                <!-- Modal update-->
                <div class="modal fade" id="editmodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลรับบริการ</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                    <input type="hidden" name="service_id" id="service_id" >
                    
    
                       
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">โต๊ะที่</span>
                                </div>
                                <select name="table_id" id="table_id" class="form-control"><?php for($num=1;$num<=30;$num++){echo "<option>$num</option>";}?> </select>
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">จำนวนที่นั่งขณะนี้</span>
                                </div>
                                <input type="text" class="form-control"   name="service_number" id="service_number" placeholder="กรุณากรอกจำนวน"   require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จำนวนสูงสุด</span>
                                </div>
                                <input type="text" class="form-control" id="service_numberh"  name="service_numberh"   placeholder="กรุณากรอกจำนวนสูงสุด"  require>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="service_status"   class="form-control">
                                    <option value="0"  >ไม่ว่าง
                                    </option>
                                    <option value="1"  >ว่าง
                                    </option>
                                </select>
                            </div>
                        </div>
                        

                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
                  
    </form>

    <form action="" method="POST" enctype="multipart/form-data">
                
        <!-- Modal insert-->
        <div class="modal fade" id="adddata"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลรับบริการ</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
        
                    <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">โต๊ะที่</span>
                                </div>
                                <select name="table_id" class="form-control"><?php for($num=1;$num<=30;$num++){echo "<option>$num</option>";}?> </select>
                                 
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control"   name="service_number"  placeholder="กรุณากรอกจำนวน"   require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จำนวนสูงสุด</span>
                                </div>
                                <input type="text" class="form-control"   name="service_numberh"   placeholder="กรุณากรอกจำนวนสูงสุด"  require>
                                
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="service_status"   class="form-control">
                                    <option value="0"  >ไม่ว่าง
                                    </option>
                                    <option value="1"  >ว่าง
                                    </option>
                                </select>
                            </div>
                        </div>
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
        
    </form>


    <h1 class="text-center mt-3">ข้อมูลรับบริการ</h1>
    <hr>
     <!-- Button trigger modal -->
     <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#adddata">เพิ่ม <i class="fas fa-plus"></i></button>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>เลขที่โต๊ะ</th>
                <th>จำนวนที่นั่งขณะนี้</th>
                <th>จำนวนสูงสุด</th>
                <th>สถานะ</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                
            

                $querydata = mysqli_query($conn,"SELECT * FROM services");
                while($row = mysqli_fetch_array($querydata)){
            ?>
            <tr>
                <td><?php echo $row['service_id'];?></td>
                <td><?php echo $row['table_id'];?></td>
                <td><?php echo $row['service_number'];?></td>
                <td><?php echo $row['service_numberh'];?></td>
                    <?php
                        $st = '';
                            if($row['service_status'] == 1){
                                $st = "ว่าง";
                            }else{
                                $st = "ไม่ว่าง";
                            }
                    echo '<td>' . $st . '</td>' ;

                    ?>        
            
                <td><button type="button" class="btn btn-info editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                     <a href="service.php?del=<?php echo $row['service_id'];?>" class="btn btn-success">ลบ <i class="fas fa-trash-alt"></i></a></td>
                
            </tr>
            
        </tbody>
        <?php } ?>

    </table>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>

<script>
        $(document).ready(function (){
            $('.editbtn').on('click',function(){

                $('#editmodal').modal('show');
                    $st = $(this).closest('tr');
                    var data = $st.children("td").map(function(){
                        return $(this).text();
                    }).get();
                    console.log(data);

                    $('#service_id').val(data[0]);
                    $('#table_id').val(data[1]);
                    $('#service_number').val(data[2]);
                    $('#service_numberh').val(data[3]);
                    $('#service_status').val(data[4]);       

            });    
        });
    </script>

</body>
<?php   include('include/footer.php');?>
</html>
<?php } ?>
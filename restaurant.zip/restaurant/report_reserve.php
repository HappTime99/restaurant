<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{

    
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
         include('include/linkcss.php');
         include('include/linkjs.php');
         include('include/connect.php');
         include('include/sidebar_menu.php');
    ?>
    <h1 class="text-center mt-3">รายงานผลจองโต๊ะอาหาร</h1>
    <hr>
    <form action="" method="post">
        <div class="container-fluid">
            <div class="row mt-5">
                <div class="col mb-5">
                    <label for="">เริ่ม</label>
                    <input type="date" name="startdate" id="">
                </div>
                <div class="col">
                    <label for="">ถึง</label>
                    <input type="date" name="enddate" id="">
                </div>
                <div>
                    <button type="submit" name="submit" class="btn btn-dark">ตกลง</button>
                </div>
            </div>
            <table class="table">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>โต๊ะที่จอง</th>
                        <th>ชื่อผู้จอง</th>
                        <th>นามสกุลผู้จอง</th>
                        <th>วันที่ใช้บริการ</th>
                        <th>เบอร์โทร</th>
                        <th>จำนวน</th>
                        <th>สถานะ</th>
                        <th>ชื่อผู้ให้บริการ</th>
                        <th>นามสกุลผู้ให้บริการ</th>
                    </tr>
                </thead>
                <tbody>
                    <?php

                        if(isset($_POST['submit'])){
                            $startdate = $_POST['startdate'];
                            $enddate = $_POST['enddate'];
                            $query = mysqli_query($conn,"SELECT * FROM reserve_table WHERE mdate BETWEEN '$startdate'AND '$enddate' ORDER BY mdate");
                            while($row = mysqli_fetch_array($query)){
                            
                        
                    ?>
                    <tr>
                        <td><?php echo $row['table_id'];?></td>
                        <td><?php echo $row['reserve_id'];?></td>
                        <td><?php echo $row['reserve_name'];?></td>
                        <td><?php echo $row['reserve_surname'];?></td>
                        <td><?php echo $row['mdate'];?></td>
                        <td><?php echo $row['reserve_tel'];?></td>
                        <td><?php echo $row['reserve_number'];?></td>
                        <?php
                        $st = '';
                            if($row['status_id'] == 1){
                                $st = "มาใช้บริการ";
                            }else{
                                $st = "ยังไม่มาใช้บริการ";
                            }
                            echo '<td>' . $st . '</td>' ;
                        ?> 
                        <td><?php echo $row['employee_name'];?></td>
                        <td><?php echo $row['employee_surname'];?></td>
                    </tr>
                </tbody>
                <?php } }?>
            </table>
        </div>
    </form>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php   include('include/footer.php');?>
</html>
<?php } ?>
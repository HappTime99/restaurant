<?php
   session_start();

   if (!isset($_SESSION['userid'])) {
       header("Location: login.php");
   }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    
</head>
<body>
    <?php 
        include('include/linkcss.php');
        include('include/linkjs.php');
        include('include/connect.php');
        include('include/sidebar_menu.php');

        
        //query
        $querydata = mysqli_query($conn,"SELECT * FROM customer");


        //insert
        if(isset($_POST['insert'])){
            $fname = $_POST['customer_name'];
            $lname = $_POST['customer_surname'];
            $ptel = $_POST['customer_tel'];
            $paddress = $_POST['customer_address'];
           

            $insertdata = mysqli_query($conn,"INSERT INTO customer(customer_name,customer_surname,customer_tel,customer_address) VALUES('$fname','$lname','$ptel','$paddress')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href='customer.php'</script>";
              } 
        }

        //update
        if(isset($_POST['update'])){
            $userid = $_POST['customer_id'];
            $fname = $_POST['customer_name'];
            $lname = $_POST['customer_surname'];
            $ptel = $_POST['customer_tel'];
            $paddress = $_POST['customer_address'];
            $status = $_POST['customer_status'];

            $updatedata = mysqli_query($conn,"UPDATE customer SET
            customer_name = '$fname',
            customer_surname = '$lname',
            customer_tel = '$ptel',
            customer_address = '$paddress',
            customer_status = '$status'
            WHERE customer_id = '$userid'
            ");
          
            if($updatedata) {
                echo "<script>alert('Update Successfully!');</script>";
                echo "<script>window.location.href='customer.php'</script>";
              } 
        }
        
        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM customer WHERE customer_id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href='customer.php'</script>";
              } 
        }
          
    ?>

    <form action="" method="POST">
                
        <!-- Modal insert-->
        <div class="modal fade" id="adddata"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลลูกค้า</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               
                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">ชื่อ</span>
                        </div>
                        <input type="text" class="form-control"  name="customer_name" placeholder="กรุณากรอกชื่อ"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">นามสกุล</span>
                        </div>
                        <input type="text" class="form-control"  name="customer_surname"   placeholder="กรุณากรอกนามสกุล"  require>
                        
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">เบอร์โทร</span>
                        </div>
                        <input type="text" class="form-control"  name="customer_tel"  placeholder="กรุณากรอกเบอร์โทร"  require>
                    </div>
                </div>

                <div class="form-group">
                    <div class="input-group mb-4 ">
                        <div class="input-group-prepend">
                            <span class="input-group-text"
                                    style="color: #d80041;min-width: 130px">ที่อยู่</span>
                        </div>
                        <textarea type="text" class="form-control" name="customer_address" placeholder="กรุณากรอกที่อยู่"require> 
                        </textarea >
                    </div>
                </div>

                
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
            </div>
            </div>
        </div>
        </div>

    </form>

        
    <form action="" method="post">
                
                <!-- Modal update-->
                <div class="modal fade" id="editmodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลลูกค้า</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" name="customer_id" id="customer_id">
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ชื่อ</span>
                                </div>
                                <input type="text" class="form-control" id="customer_name"  name="customer_name" placeholder="กรุณากรอกชื่อ" require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">นามสกุล</span>
                                </div>
                                <input type="text" class="form-control" id="customer_surname"  name="customer_surname"  placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">เบอร์โทร</span>
                                </div>
                                <input type="text" class="form-control" id="customer_tel"  name="customer_tel"  placeholder="กรุณากรอกเบอร์โทร"  require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ที่อยู่</span>
                                </div>
                                <textarea type="text" placeholder="กรุณากรอกรายละเอียด" id="customer_address"  name="customer_address" class="form-control"    require> 
                                </textarea >
                            </div>
                        </div>

                        

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="customer_status"  class="form-control">
                                    <option value="0"  >ไม่ใช้งาน
                                    </option>
                                    <option value="1"  >ใช้งาน
                                    </option>
                                </select>
                            </div>
                        </div>

                        

                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
                  
    </form>
    

    <h1 class="text-center mt-3">ข้อมูลลูกค้า </h1>
    <hr>
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#adddata">
            เพิ่ม <i class="fas fa-plus"></i>
        </button>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>ชื่อ</th>
                <th>นามสกุล</th>
                <th>เบอร์โทร</th>
                <th>ที่อยู่</th>
                
                <th>สถานะ</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php
                while($row = mysqli_fetch_array($querydata)){
            ?>
            <tr>
                <td><?php echo $row['customer_id'];?></td>
                <td><?php echo $row['customer_name'];?></td>
                <td><?php echo $row['customer_surname'];?></td>
                <td><?php echo $row['customer_tel'];?></td>
                <td><?php echo $row['customer_address'];?></td>
                
                <?php
                      $st = '';
                      if($row['customer_status'] == 0 ){
                          $st = "ไม่ใช้งาน";
                      }else{
                          $st = "ใช้งาน";
                      }
                  echo '<td>' . $st . '</td>' ;
                  ?>
                <td><button type="button" class="btn btn-danger editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                    <a href="customer.php?del=<?php echo $row['customer_id'];?>" class="btn btn-dark">ลบ <i class="fas fa-trash-alt"></i></a>
            </td>
                
            </tr>
            <?php } ?>
        </tbody>

    </table>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
    <script>
        $(document).ready(function (){
            $('.editbtn').on('click',function(){

                $('#editmodal').modal('show');
                    $st = $(this).closest('tr');
                    var data = $st.children("td").map(function(){
                        return $(this).text();
                    }).get();
                    console.log(data);

                    $('#customer_id').val(data[0]);
                    $('#customer_name').val(data[1]);
                    $('#customer_surname').val(data[2]);
                    $('#customer_tel').val(data[3]);
                    $('#customer_address').val(data[4]);
                    $('#customer_status').val(data[5]);
                    
                    

            });    
        });
    </script>
    
</body>
<?php   include('include/footer.php');?>

</html>
<?php } ?>
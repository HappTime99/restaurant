-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 21, 2021 at 03:19 PM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `customer_id` int(11) NOT NULL,
  `customer_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `customer_surname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `customer_address` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `customer_tel` int(20) NOT NULL,
  `customer_status` int(5) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`customer_id`, `customer_name`, `customer_surname`, `customer_address`, `customer_tel`, `customer_status`) VALUES
(1, 'บัญชา                        ', 'เติมสุข', '13/4 หมู่ที่ 3 ซอยสุขสวัสดิ์ 80, ถนนสุขสวัสดิ์, บางครุ พระประแดง samutprakarn สมุทรปราการ 10130                                        ', 2147483645, 1),
(2, 'บุญมี', 'สง่างาม', ' หมู่ 6/1150 ซอย 125 ประชาอุทิศ แขวง ทุ่งครุ เขตทุ่งครุ กรุงเทพมหานคร 10140\r\n                        ', 889465477, 1),
(3, 'บุญชัย', 'แซ่ตั้ง', 'หมู่ 10 39/264 ซอย 121 ประชาอุทิศ แขวง ทุ่งครุ เขตทุ่งครุ กรุงเทพมหานคร 10140\r\n                        ', 887649788, 1),
(4, 'บุญโชค', 'มีดี', 'สุขสวัสดิ์ 76 ลัดหลวง อำเภอพระประแดง สมุทรปราการ 10131\r\n                        ', 983757351, 0);

-- --------------------------------------------------------

--
-- Table structure for table `food`
--

CREATE TABLE `food` (
  `food_id` int(11) NOT NULL,
  `food_pic_path` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `food_menu` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `food_price` int(5) NOT NULL,
  `food_category` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `food_status` int(5) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `food`
--

INSERT INTO `food` (`food_id`, `food_pic_path`, `food_menu`, `food_price`, `food_category`, `food_status`) VALUES
(1, 'ข้าวผัดกะเพราหมูย่าง.jpg', 'ข้าวผัดกะเพราหมูย่าง', 40, 'จานเดียว', 0),
(2, 'ข้าวผัดหมู.jpg', 'ข้าวผัดหมู', 35, 'จานเดียว', 0),
(3, 'ข้าวหมกไก่.jpg', 'ข้าวหมกไก่', 40, 'จานเดียว', 0),
(4, 'ผัดไทยกุ้งสด.jpg', 'ผัดไทยกุ้งสด', 40, 'จานเดียว', 0),
(5, 'ข้าวหมูแดง.jpg', 'ข้าวหมูแดง', 50, 'จานเดียว', 1),
(6, 'ข้าวหมูกรอบ.jpg', 'ข้าวหมูกรอบ', 45, 'จานเดียว', 1),
(7, 'ข้าวมันไก่.jpg', 'ข้าวมันไก่', 30, 'จานเดียว', 1),
(8, 'ข้าวขาหมู.png', 'ข้าวขาหมู', 30, 'จานเดียว', 1),
(9, 'ข้าวไก่กระเทียม.jpg', 'ข้าวไก่กระเทียม', 35, 'จานเดียว', 0);

-- --------------------------------------------------------

--
-- Table structure for table `order_food`
--

CREATE TABLE `order_food` (
  `order_id` int(11) NOT NULL,
  `order_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `order_food` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mdate` datetime NOT NULL DEFAULT current_timestamp(),
  `order_table` int(5) NOT NULL,
  `order_category` int(5) NOT NULL DEFAULT 1,
  `order_number` int(5) NOT NULL,
  `order_status` int(5) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `order_food`
--

INSERT INTO `order_food` (`order_id`, `order_image`, `order_food`, `mdate`, `order_table`, `order_category`, `order_number`, `order_status`) VALUES
(1, '', 'ข้าวผัดกะเพราหมูย่าง', '2021-11-29 16:36:26', 2, 0, 2, 0),
(2, '', 'ข้าวหมกไก่', '2021-11-29 17:14:43', 7, 0, 0, 0),
(3, '', 'ข้าวหมูแดง', '2021-12-09 12:31:06', 11, 0, 5, 0),
(4, '', 'ข้าวขาหมู', '2021-12-09 12:31:33', 3, 1, 4, 1),
(5, '', 'ข้าวไก่กระเทียม', '2021-12-09 12:31:55', 20, 1, 1, 1),
(6, '', 'ข้าวขาหมู', '2021-12-12 20:15:27', 14, 0, 3, 1),
(7, '', 'ข้าวผัดหมู', '2021-12-18 12:56:19', 4, 0, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `pay`
--

CREATE TABLE `pay` (
  `pay_id` int(11) NOT NULL,
  `pay_food` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `pay_number` int(10) NOT NULL,
  `pay_price` int(10) NOT NULL,
  `pay_sum` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `pay`
--

INSERT INTO `pay` (`pay_id`, `pay_food`, `pay_number`, `pay_price`, `pay_sum`) VALUES
(1, 'ข้าวผัดหมู', 2, 40, 80),
(2, 'ข้าวขาหมู', 4, 30, 120),
(3, 'ข้าวผัดกะเพราหมูย่าง', 2, 40, 80),
(4, 'ข้าวไก่กระเทียม', 1, 35, 35),
(5, 'ข้าวหมูแดง', 5, 50, 250);

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(11) NOT NULL,
  `list_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `report`
--

INSERT INTO `report` (`id`, `list_name`) VALUES
(1, 'customer'),
(2, 'order_food'),
(3, 'pay'),
(4, 'reserve_table'),
(5, 'services'),
(6, 'user');

-- --------------------------------------------------------

--
-- Table structure for table `reserve_table`
--

CREATE TABLE `reserve_table` (
  `table_id` int(11) NOT NULL,
  `reserve_id` int(5) NOT NULL,
  `reserve_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `reserve_surname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `mdate` datetime NOT NULL DEFAULT current_timestamp(),
  `reserve_tel` int(20) NOT NULL,
  `reserve_number` int(5) NOT NULL,
  `status_id` int(5) NOT NULL DEFAULT 1,
  `employee_name` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `employee_surname` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `reserve_table`
--

INSERT INTO `reserve_table` (`table_id`, `reserve_id`, `reserve_name`, `reserve_surname`, `mdate`, `reserve_tel`, `reserve_number`, `status_id`, `employee_name`, `employee_surname`) VALUES
(1, 11, 'บุญชัย', 'แซ่ตั้ง', '2021-11-27 12:19:51', 875489755, 4, 0, 'วิลัยลักษณ์', 'บุญมี'),
(2, 7, 'บัญชา', 'เติมสุข', '2021-11-27 14:27:31', 889764544, 5, 1, 'วิริยะ', 'บุญนาค'),
(3, 2, 'บุญโชค', 'มีดี', '2021-12-09 12:35:51', 875468744, 2, 0, 'วีรชัย', 'โชคทรัพย์'),
(4, 20, 'ยินดี', 'มีสุข', '2021-12-09 12:37:35', 779845644, 3, 0, 'วิลัยลักษณ์', 'บุญมี'),
(5, 4, 'บัญชา', 'เติมสุข', '2021-12-18 13:51:27', 2147483644, 4, 1, 'สมฤทัย	', 'นำดี');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `table_id` int(5) NOT NULL,
  `service_number` int(5) NOT NULL,
  `service_numberh` int(5) NOT NULL,
  `service_status` int(5) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `table_id`, `service_number`, `service_numberh`, `service_status`) VALUES
(1, 19, 3, 5, 0),
(2, 2, 2, 5, 0),
(3, 11, 5, 5, 0),
(4, 20, 1, 5, 0),
(5, 3, 3, 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `fname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `tel` int(20) NOT NULL,
  `paddress` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `pusername` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `ppassword` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `status` int(5) NOT NULL DEFAULT 1,
  `userlevel` int(5) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `fname`, `lname`, `tel`, `paddress`, `pusername`, `ppassword`, `status`, `userlevel`) VALUES
(1, 'วิริยะ', 'บุญนาค', 21474836, 'หมู่ 6 39/264 ซอย 121 ประชาอุทิศ แขวง ทุ่งครุ เขตทุ่งครุ กรุงเทพมหานคร 10141', 'admin', '21232f297a57a5a743894a0e4a801fc3', 1, 0),
(2, 'วีรชัย', 'โขคทรัพย์', 887645476, '115 4 หมู่ 4 ซ. สุขสวัสดิ์ 66 กรุงเทพมหานคร อำเภอพระประแดง สมุทรปราการ 10130', 'nanza', '71ff1e419faca96429abdafab87c618f', 0, 0),
(3, 'สมฤทัย', 'นำดี', 994431766, 'สุขสวัสดิ์ 64 ซอย 3 ลัดหลวง อำเภอพระประแดง สมุทรปราการ 10130', 'somsak', 'ad485d82bc7abcc73addc2f0a7821cc8', 0, 0),
(4, 'สามัคคี', 'คือพลัง', 994847333, '81/3 หมู่ที่18 ซอย สุขสวัสดิ์ 64 กรุงเทพมหานคร อำเภอพระประแดง สมุทรปราการ 10130', 'samak', 'beb5aad658ed462e02fbae9371fe281b', 0, 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `food`
--
ALTER TABLE `food`
  ADD PRIMARY KEY (`food_id`);

--
-- Indexes for table `order_food`
--
ALTER TABLE `order_food`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `pay`
--
ALTER TABLE `pay`
  ADD PRIMARY KEY (`pay_id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reserve_table`
--
ALTER TABLE `reserve_table`
  ADD PRIMARY KEY (`table_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `food`
--
ALTER TABLE `food`
  MODIFY `food_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `order_food`
--
ALTER TABLE `order_food`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `pay`
--
ALTER TABLE `pay`
  MODIFY `pay_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reserve_table`
--
ALTER TABLE `reserve_table`
  MODIFY `table_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

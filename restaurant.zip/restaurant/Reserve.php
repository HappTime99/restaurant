<?php
   session_start();

   if (!isset($_SESSION['userid'])) {
       header("Location: login.php");
   }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        include('include/linkjs.php');
        include('include/linkcss.php');
        include('include/connect.php');
        include('include/sidebar_menu.php');

        //insert
        if(isset($_POST['insert'])){
            
            $re_name = $_POST['reserve_name'];
            $re_surname = $_POST['reserve_surname'];
            $re_tel = $_POST['reserve_tel'];
            $re_number = $_POST['reserve_number'];
            $status_id = $_POST['status_id'];
            $em_name = $_POST['employee_name'];
            $em_surname = $_POST['employee_surname'];

            $insertdata = mysqli_query($conn,"INSERT INTO reserve_table(reserve_name,reserve_surname,reserve_tel,reserve_number,employee_name,employee_surname)
            VALUES('$re_name','$re_surname','$re_tel','$re_number','$status_id','$em_name','$em_surname')");
            if ($insertdata) {
                echo "<script>alert('Record Inserted Successfully!');</script>";
                echo "<script>window.location.href='reserve.php'</script>";
            } 
        }

        //update
        if(isset($_POST['update'])){
            $userid = $_POST['table_id'];
            $re_id = $_POST['reserve_id'];
            $re_name = $_POST['reserve_name'];
            $re_surname = $_POST['reserve_surname'];
            $re_tel = $_POST['reserve_tel'];
            $re_number = $_POST['reserve_number'];
            $status_id = $_POST['status_id'];
            $em_name = $_POST['employee_name'];
            $em_surname= $_POST['employee_surname'];

            $updatedata = mysqli_query($conn,"UPDATE reserve_table SET
            reserve_id = '$re_id',
            reserve_name = '$re_name',
            reserve_surname = '$re_surname',
            reserve_tel = '$re_tel',
            reserve_number = '$re_number',
            status_id = '$status_id',
            employee_name = '$em_name',
            employee_surname = '$em_surname'
            WHERE table_id = '$userid'
            ");
            if($updatedata ) {
                echo "<script>alert('Update Successfully!');</script>";
                echo "<script>window.location.href='reserve.php'</script>";
              } 
        }

        //delete
        if(isset($_GET['del'])){
            $userid = $_GET['del'];
            $deletedata = mysqli_query($conn,"DELETE FROM reserve_table WHERE table_id = '$userid'");
            if($deletedata) {
                echo "<script>alert('Delete Successfully!');</script>";
                echo "<script>window.location.href='reserve.php'</script>";
              } 
        }

    ?>

<form action="" method="post" enctype="multipart/form-data"> 
                
                <!-- Modal update-->
                <div class="modal fade" id="editmodal"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">แก้ไขข้อมูลจองโต๊ะอาหาร</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                    <input type="hidden" name="table_id" id="table_id" >
                    
    
                       
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จองโต๊ะที่</span>
                                </div>
                                <select name="reserve_id" id="reserve_id" class="form-control"><?php for($num=1;$num<=30;$num++){echo "<option>$num</option>";}?> </select>
                                
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">ชื่อผู้จอง</span>
                                </div>
                                <input type="text" class="form-control" id="reserve_name"  name="reserve_name" placeholder="กรุณากรอกชื่อ" require>
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">นามสกุลผู้จอง</span>
                                </div>
                                <input type="text" class="form-control" id="reserve_surname"  name="reserve_surname"   placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">เบอร์โทร</span>
                                </div>
                                <input type="text" class="form-control" id="reserve_tel"  name="reserve_tel"   placeholder="กรุณากรอกเบอร์โทร"  require>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control" id="reserve_number"  name="reserve_number"   placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                        style="color: #d80041;min-width: 130px">สถานะ</span>
                                </div>
                                <select name="status_id"   class="form-control">
                                    <option value="0"  >ยังไม่มาใช้บริการ
                                    </option>
                                    <option value="1"  >มาใช้บริการ
                                    </option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ชื่อผู้ให้บริการ</span>
                                </div>
                                <input type="text" class="form-control" id="employee_name"  name="employee_name"   placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">นามสกุลผู้ให้บริการ</span>
                                </div>
                                <input type="text" class="form-control" id="employee_surname"  name="employee_surname"   placeholder="กรุณากรอกนามสกุล"  require>
                                
                            </div>
                        </div>

                    </div>
                   
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="update" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
                  
    </form>

    <form action="" method="POST" enctype="multipart/form-data">
                
        <!-- Modal insert-->
        <div class="modal fade" id="adddata"  tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">เพิ่มข้อมูลจองโต๊ะ</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จองโต๊ะที่</span>
                                </div>
                                <select name="reserve_id" id="" class="form-control">
                                    <?php  for($num = 1; $num<=30; $num++){ echo "<option>".$num."</option>"; } ?>
                                </select>
                            </div>
                        </div>
        
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ชื่อผู้จอง</span>
                                </div>
                                <input type="text" class="form-control"  name="reserve_name" placeholder="กรุณากรอกชื่อผู้จอง"  require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">นามสกุลผู้จอง</span>
                                </div>
                                <input type="text" class="form-control"  name="reserve_surname" placeholder="กรุณากรอกนามสกุลผู้จอง"  require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">เบอร์โทร</span>
                                </div>
                                <input type="text" class="form-control"  name="reserve_tel"   placeholder="กรุณากรอกเบอร์โทร"  require>
                                
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">จำนวน</span>
                                </div>
                                <input type="text" class="form-control"  name="reserve_number"   placeholder="กรุณากรอกจำนวน"  require>
                                
                            </div>
                        </div>
        
                        <div class="form-group">
                                    <div class="input-group mb-4 ">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text"
                                                style="color: #d80041;min-width: 130px">สถานะ</span>
                                        </div>
                                        <select name="status_id"   class="form-control">
                                            <option value="0"  >ยังไม่มาใช้บริการ
                                            </option>
                                            <option value="1"  >มาใช้บริการ
                                            </option>
                                        </select>
                                    </div>
                                </div>

                                <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">ชื่อให้บริการ</span>
                                </div>
                                <input type="text" class="form-control"  name="employee_name"   placeholder="กรุณากรอกชื่อผู้ให้บริการ"  require>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="input-group mb-4 ">
                                <div class="input-group-prepend">
                                    <span class="input-group-text"
                                            style="color: #d80041;min-width: 130px">นามสกุลผู้ให้บริการ</span>
                                </div>
                                <input type="text" class="form-control"  name="employee_surname"   placeholder="กรุณากรอกนามสกุลผู้ให้บริการ"  require>
                                
                            </div>
                        </div>
        
                        
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" name="insert" class="btn btn-primary">Save changes</button>
                    </div>
                    </div>
                </div>
                </div>
        
    </form>


    <h1 class="text-center mt-3">ข้อมูลจองโต๊ะอาหาร</h1>
    <hr>
     <!-- Button trigger modal -->
     <button type="button" class="btn btn-dark" data-bs-toggle="modal" data-bs-target="#adddata">เพิ่ม <i class="fas fa-plus"></i></button>
    <table class="table">
        <thead>
            <tr>
                <th>#</th>
                <th>จองโต๊ะ</th>
                <th>ชื่อผู้จอง</th>
                <th>นามสกุลผู้จอง</th>
                <th>วันที่ใช้บริการ</th>
                <th>เบอร์โทร</th>
                <th>จำนวน/โต๊ะ</th>
                <th>สถานะ</th>
                <th>ชื่อพนักงาน</th>
                <th>นามสกุลพนักงาน</th>
                <th>จัดการ</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                
            

                $querydata = mysqli_query($conn,"SELECT * FROM reserve_table");
                while($row = mysqli_fetch_array($querydata)){
            ?>
            <tr>
                <td><?php echo $row['table_id'];?></td>
                <td><?php echo $row['reserve_id'];?></td>
                <td><?php echo $row['reserve_name'];?></td>
                <td><?php echo $row['reserve_surname'];?></td>
                <td><?php echo $row['mdate'];?></td>
                <td><?php echo $row['reserve_tel'];?></td>
                <td><?php echo $row['reserve_number'];?></td>
               
                    <?php
                        $st = '';
                            if($row['status_id'] == 1){
                                $st = "มาใช้บริการ";
                            }else{
                                $st = "ยังไม่มาใช้บริการ";
                            }
                    echo '<td>' . $st . '</td>' ;

                    ?>        
                <td><?php echo $row['employee_name'];?></td>
                <td><?php echo $row['employee_surname'];?></td>
                <td><button type="button" class="btn btn-info editbtn">แก้ไข <i class="fas fa-edit"></i></button>
                     <a href="reserve.php?del=<?php echo $row['table_id'];?>" class="btn btn-success">ลบ <i class="fas fa-trash-alt"></i></a></td>
                
            </tr>
            
        </tbody>
        <?php } ?>

    </table>

    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>

<script>
        $(document).ready(function (){
            $('.editbtn').on('click',function(){

                $('#editmodal').modal('show');
                    $st = $(this).closest('tr');
                    var data = $st.children("td").map(function(){
                        return $(this).text();
                    }).get();
                    console.log(data);

                    $('#table_id').val(data[0]);
                    $('#reserve_id').val(data[1]);
                    $('#reserve_name').val(data[2]);
                    $('#reserve_surname').val(data[3]);
                    $('#reserve_tel').val(data[5]);
                    $('#reserve_number').val(data[6]);
                    $('#status_id').val(data[7]);
                    $('#employee_name').val(data[8]);
                    $('#employee_surname').val(data[9]);
      

            });    
        });
    </script>

</body>
<?php   include('include/footer.php');?>
</html>

<?php } ?>
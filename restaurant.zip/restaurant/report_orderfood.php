<?php
    session_start();
    if(!isset($_SESSION['userid'])){
        header("Location: login.php");
    }else{
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    
    include('include/linkcss.php');
    include('include/linkjs.php');
    include('include/connect.php');
    include('include/sidebar_menu.php');

    
    ?>
    <h1 class="text-center mt-3"> รายงานผลสั่งอาหาร</h1>
    <hr>
    <form action="" method="post">
        <div class="container-fluid">
            <div class="row mt-5 ">
                <div class="col mb-5">
                    <label for="">เริ่ม</label>
                    <input type="date" name="startdate" id="">
                </div>
                <div class="col">
                    <label for="">ถึง</label>
                    <input type="date" name="enddate" id="">
                </div>
                <div>
                    <button type="submit" name="submit" class="btn btn-success">ตกลง </button>
                </div>

            </div>
            <table class="table " >
                <thead>
                    <tr>
                        <th>#</th>
                        <th>รายการอาหาร</th>
                        <th>วันที่สั่ง</th>
                        <th>โต๊ะที่สั่ง</th>
                        <th>ประเภทอาหาร</th>
                        <th>จำนวน</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        if(isset($_POST['submit'])){
                            $startdate = $_POST['startdate'];
                            $enddate = $_POST['enddate'];
                    
                            $query = mysqli_query($conn,"SELECT * FROM order_food WHERE mdate BETWEEN '$startdate' AND '$enddate' ORDER BY mdate");
                    
                        
                           foreach($query as $row){
                            
                    ?>
                    <tr>
                        <td><?php echo $row['order_id'];?></td>
                        <td><?php echo $row['order_food'];?></td>
                        <td><?php echo $row['mdate'];?></td>
                        <td><?php echo $row['order_table'];?></td>
                        <?php
                             
                             $or_cat = '';
                             if($row['order_category'] == 1 ){
                                 $or_cat = "ร้านอาหาร";
                             }else{
                                 $or_cat = "กลับบ้าน";
                             }
                           echo "<td>". $or_cat."</td>" ;
                          
                        ?>
                        <td><?php echo $row['order_number'];?></td>
                    </tr>
                </tbody>
                <?php }  } ?>
            </table>
            
        </div>
    </form>
    <script>
        $(document).ready( function () {
              $('.table').DataTable();
          } );
    </script>
</body>
<?php   include('include/footer.php');?>

</html>
<?php } ?>